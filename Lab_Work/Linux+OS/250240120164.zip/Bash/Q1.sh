#!/bin/bash
#1. Accept the first name, middle name, and last name of a person in variables fname, mname and lname respectively. Greet the person (take his full name) using appropriate message. 

echo "Enter first name: "
read fname

echo "Enter Middle name: "
read mname

echo "Last name: "
read lname

echo "Hello, $fname $mname $lname!"


