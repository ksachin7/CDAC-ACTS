#!/bin/bash

echo "Enter first name"
read fname

echo "Enter Middle name"
read mname

echo "Last name"
read lname

echo "Hello, $fname $mname $lname "


