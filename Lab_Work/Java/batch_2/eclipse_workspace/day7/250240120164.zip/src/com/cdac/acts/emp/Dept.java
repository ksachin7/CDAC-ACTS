package com.cdac.acts.emp;

public enum Dept {
    HR, IT, SALES, ADMIN, FINANCE
}
